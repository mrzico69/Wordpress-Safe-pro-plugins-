=== Plugin Name ===
Contributors: https://www.pixelyoursite.com/boost-plugin
Donate link: https://www.pixelyoursite.com/boost-plugin
Tags: boost
Tested up to: 6.2
Stable tag: 2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Automatically capture and show recent visitors’ activity as nice, auto-vanishing pop-ups. We call them BOOSTS.

== Description ==

Automatically capture and show recent visitors’ activity as nice, auto-vanishing pop-ups. We call them BOOSTS.

== Installation ==

== Frequently Asked Questions ==

= A question that someone might have =

= What about foo bar? =

== Screenshots ==

== Changelog ==

== Arbitrary section ==

== A brief Markdown Example ==
