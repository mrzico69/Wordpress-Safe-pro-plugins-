<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://www.pixelyoursite.com/boost-plugin
 * @since      1.0.0
 *
 * @package    Boost
 * @subpackage Boost/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Boost
 * @subpackage Boost/public
 * @author     https://www.pixelyoursite.com/boost-plugin
 */
class BoostPublic {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $plugin_name The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $version The current version of this plugin.
	 */
	private $version;

	//private $notification_model;

	private $action_model;

	private $settings_model;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @param string $plugin_name The name of the plugin.
	 * @param string $version The version of this plugin.
	 * @since    1.0.0
	 *
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

		//$this->notification_model = new BoostNotificationModel( $plugin_name, $version );
		$this->action_model = new BoostActionModel( $plugin_name, $version );
		$this->settings_model = new BoostSettingsModel( $plugin_name, $version );
	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in BoostLoader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The BoostLoader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name . '_notifications', BOOST_PLUGIN_URL . 'assets/css/notifications-style.min.css', array(), $this->version );
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in BoostLoader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The BoostLoader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		if ( !$this->check_elementor_editor() ) {

			$leads_triggers = $this->get_leads_triggers();

			wp_enqueue_script( $this->plugin_name . '_public', BOOST_PLUGIN_URL . 'public/js/boost-public.min.js', array( 'jquery' ), $this->version );
			wp_localize_script( $this->plugin_name . '_public', 'BOOST_public', array(
				'settings'                      => $this->settings_model->get_settings( array(
					'boost-visibility-time',
					'approximate-time-between-boosts',
					'close-boosts',
					'start-boosts-after'
				) ),
				'ajaxurl'                       => admin_url( 'admin-ajax.php' ),
				'notifications_part_load_nonce' => wp_create_nonce( 'boost_notifications_part_load_nonce' ),
				'submit_form_nonce'             => wp_create_nonce( 'boost_submit_form_nonce' ),
				'leads_triggers'                => $leads_triggers,
				'cookie'                        => $this->get_user_cookie(),
			) );
		}
	}

	/**
	 * AJAX callback function.
	 */
	public function boost_submit_form_ajax_handler() {
		$nonce = empty( $_POST[ 'nonce' ] ) ? '' : sanitize_text_field( wp_unslash( $_POST[ 'nonce' ] ) );
		if ( !wp_verify_nonce( $nonce, 'boost_submit_form_nonce' ) || !isset( $_POST[ 'boost_id' ] ) || !isset( $_POST[ 'user_name' ] ) ) {
			die( __( 'Error', 'boost' ) );
		}
		// Sanitize inputs before they reach SQL contexts.
		$boost_id    = absint( $_POST[ 'boost_id' ] );
		$user_name   = sanitize_text_field( wp_unslash( $_POST[ 'user_name' ] ) );
		$actionModel = new BoostActionModel( $this->get_plugin_name(), $this->get_version() );
		$actionModel->create_action_entry( $boost_id, 'leads', $user_name );
		wp_die();
	}

	/**
	 * AJAX callback function.
	 */
	public function boost_notifications_part_load_ajax_handler() {
		$nonce = empty( $_POST[ 'nonce' ] ) ? '' : sanitize_text_field( wp_unslash( $_POST[ 'nonce' ] ) );
		if ( !wp_verify_nonce( $nonce, 'boost_notifications_part_load_nonce' ) || !isset( $_POST[ 'page' ] ) || !isset( $_POST[ 'current_url' ] ) ) {
			die( __( 'Error', 'boost' ) );
		}
		// Cast page to int, validate current_url as a URL to neutralize SQL metacharacters.
		$page        = absint( $_POST[ 'page' ] );
		$current_url = esc_url_raw( wp_unslash( $_POST[ 'current_url' ] ) );

		$notificationModel       = new BoostNotificationModel( $this->get_plugin_name(), $this->get_version() );
		$notifications_part_html = $notificationModel->get_notifications_html( $page, 25, $current_url );

		wp_send_json_success( array( 'notifications_part_html' => $notifications_part_html ) );
		wp_die();
	}

	public function get_plugin_name() {
		return $this->plugin_name;
	}

	public function get_version() {
		return $this->version;
	}

	public function get_leads_triggers() {
		global $wpdb;

		$table_leads_data = $wpdb->prefix . TABLE_BOOSTS_LEADS_DATA;
		$table_boosts = $wpdb->prefix . TABLE_BOOSTS;
		$table_integrated_forms_data = $wpdb->prefix . TABLE_BOOSTS_INTEGRATED_FORMS_DATA;

		$sql = "SELECT `capture_url`, `form_selector`, `boost_id`, `form_username_field`, `form_surname_field` FROM $table_leads_data 
				LEFT JOIN $table_boosts ON ($table_boosts.`id` = $table_leads_data.`boost_id`)
				WHERE $table_boosts.`active` = '1' AND $table_boosts.`draft` <> '1';";

		if ( ( $leads_triggers = $wpdb->get_results( $sql, ARRAY_A ) ) == null ) {
			$leads_triggers = array();
		}

		$sql = "SELECT `integrated_form`, `form_selector`, `form_id`, `boost_id`, `form_username_field`, `form_surname_field` FROM $table_integrated_forms_data 
				LEFT JOIN $table_boosts ON ($table_boosts.`id` = $table_integrated_forms_data.`boost_id`)
				WHERE $table_boosts.`active` = '1' AND $table_boosts.`draft` <> '1';";

		if ( ( $integrated_forms_triggers = $wpdb->get_results( $sql, ARRAY_A ) ) == null ) {
			$integrated_forms_triggers = array();
		}

		return array_merge( $leads_triggers, $integrated_forms_triggers );
	}

	public function get_user_cookie() {

		$cookie = array();
		$cookie_location = true;

		if ( !empty( $_COOKIE[ 'STYXKEY-BOOST_USER_LOCATION' ] ) && gettype( $_COOKIE[ 'STYXKEY-BOOST_USER_LOCATION' ] ) === 'string' ) {
			$ipInfo = BoostActionModel::decodeUserLocationCookie( $_COOKIE[ 'STYXKEY-BOOST_USER_LOCATION' ] );

			if ( empty( $ipInfo[ 'town' ] ) && empty( $ipInfo[ 'state' ] ) && empty( $ipInfo[ 'country' ] ) ) {
				$cookie_location = false;
			}
		}

		if ( empty( $_COOKIE[ 'STYXKEY-BOOST_USER_LOCATION' ] ) || !$cookie_location ) {
			$ip_address = $this->get_client_ip();
			$ipInfo = array();
			$browser_version = rand( 1, 550 ) . '.' . rand( 1, 50 );

			if ( filter_var( $ip_address, FILTER_VALIDATE_IP ) ) {

				// *********** 1 **********
				if ( empty( $ipInfo[ 'town' ] ) || empty( $ipInfo[ 'state' ] ) || empty( $ipInfo[ 'country' ] ) ) {
					if ( is_callable( 'curl_init' ) ) {
						$curl_handle = curl_init();
						curl_setopt( $curl_handle, CURLOPT_URL, 'https://ipapi.co/' . $ip_address . '/json/' );
						curl_setopt( $curl_handle, CURLOPT_CONNECTTIMEOUT, 2 );
						curl_setopt( $curl_handle, CURLOPT_RETURNTRANSFER, 1 );
						curl_setopt( $curl_handle, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/{$browser_version} (KHTML, like Gecko) Chrome/113.0.0.0 Safari/{$browser_version}" );
						$response = curl_exec( $curl_handle );
						curl_close( $curl_handle );
						if ( !empty( $response ) ) {
							$location_data = @json_decode( $response );
							$ipInfo[ 'town' ] = !empty( $location_data->city ) ? $location_data->city : ( !empty( $ipInfo[ 'town' ] ) ? $ipInfo[ 'town' ] : '' );
							$ipInfo[ 'state' ] = !empty( $location_data->region ) ? $location_data->region : ( !empty( $ipInfo[ 'state' ] ) ? $ipInfo[ 'state' ] : '' );
							$ipInfo[ 'country' ] = !empty( $location_data->country_name ) ? $location_data->country_name : ( !empty( $ipInfo[ 'country' ] ) ? $ipInfo[ 'country' ] : '' );
						}
					} else {
						$response = wp_remote_get( 'https://ipapi.co/' . $ip_address . '/json/' );
						if ( !is_wp_error( $response ) ) {
							$location_data = @json_decode( wp_remote_retrieve_body( $response ) );

							$ipInfo[ 'town' ] = !empty( $location_data->city ) ? $location_data->city : ( !empty( $ipInfo[ 'town' ] ) ? $ipInfo[ 'town' ] : '' );
							$ipInfo[ 'state' ] = !empty( $location_data->region ) ? $location_data->region : ( !empty( $ipInfo[ 'state' ] ) ? $ipInfo[ 'state' ] : '' );
							$ipInfo[ 'country' ] = !empty( $location_data->country_name ) ? $location_data->country_name : ( !empty( $ipInfo[ 'country' ] ) ? $ipInfo[ 'country' ] : '' );
						}
					}
				}

				// *********** 2 **********
				if ( empty( $ipInfo[ 'town' ] ) || empty( $ipInfo[ 'state' ] ) || empty( $ipInfo[ 'country' ] ) ) {
					if ( is_callable( 'curl_init' ) ) {
						$curl_handle = curl_init();
						curl_setopt( $curl_handle, CURLOPT_URL, 'http://ip-api.com/json/' . $ip_address );
						curl_setopt( $curl_handle, CURLOPT_CONNECTTIMEOUT, 2 );
						curl_setopt( $curl_handle, CURLOPT_RETURNTRANSFER, 1 );
						curl_setopt( $curl_handle, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/{$browser_version} (KHTML, like Gecko) Chrome/113.0.0.0 Safari/{$browser_version}" );
						$response = curl_exec( $curl_handle );
						curl_close( $curl_handle );
						if ( !empty( $response ) ) {
							$location_data = @json_decode( $response );
							$ipInfo[ 'town' ] = !empty( $location_data->city ) ? $location_data->city : ( !empty( $ipInfo[ 'town' ] ) ? $ipInfo[ 'town' ] : '' );
							$ipInfo[ 'state' ] = !empty( $location_data->regionName ) ? $location_data->regionName : ( !empty( $ipInfo[ 'state' ] ) ? $ipInfo[ 'state' ] : '' );
							$ipInfo[ 'country' ] = !empty( $location_data->country ) ? $location_data->country : ( !empty( $ipInfo[ 'country' ] ) ? $ipInfo[ 'country' ] : '' );
						}
					} else {
						$response = wp_remote_get( 'http://ip-api.com/json/' . $ip_address );
						if ( !is_wp_error( $response ) ) {
							$location_data = @json_decode( wp_remote_retrieve_body( $response ) );
							$ipInfo[ 'town' ] = !empty( $location_data->city ) ? $location_data->city : ( !empty( $ipInfo[ 'town' ] ) ? $ipInfo[ 'town' ] : '' );
							$ipInfo[ 'state' ] = !empty( $location_data->regionName ) ? $location_data->regionName : ( !empty( $ipInfo[ 'state' ] ) ? $ipInfo[ 'state' ] : '' );
							$ipInfo[ 'country' ] = !empty( $location_data->country ) ? $location_data->country : ( !empty( $ipInfo[ 'country' ] ) ? $ipInfo[ 'country' ] : '' );
						}
					}
				}
			}

			if ( empty( $ipInfo[ 'town' ] ) ) {
				$ipInfo[ 'town' ] = '';
			}
			if ( empty( $ipInfo[ 'state' ] ) ) {
				$ipInfo[ 'state' ] = '';
			}
			if ( empty( $ipInfo[ 'country' ] ) ) {
				$ipInfo[ 'country' ] = '';
			}

			// Store as JSON (not PHP serialize) to avoid PHP Object Injection on read.
			$cookie[ 'STYXKEY-BOOST_USER_LOCATION' ] = base64_encode( wp_json_encode( $ipInfo ) );
			$_COOKIE[ 'STYXKEY-BOOST_USER_LOCATION' ] = $cookie;
		}

		if ( !is_admin() && empty( $_COOKIE[ 'STYXKEY-BOOST_SESSION' ] ) ) {

			$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$characters_length = strlen( $characters );
			$random_string = '';
			for ( $i = 0; $i < 15; $i++ ) {
				$random_string .= $characters[ rand( 0, $characters_length - 1 ) ];
			}

			$cookie[ 'STYXKEY-BOOST_SESSION' ] = $random_string;
			$_COOKIE[ 'STYXKEY-BOOST_SESSION' ] = $random_string;
		}

		return $cookie;
	}

	public function get_client_ip() {
		if ( getenv( 'HTTP_CLIENT_IP' ) ) {
			$ip_address = getenv( 'HTTP_CLIENT_IP' );
		} else if ( getenv( 'HTTP_X_FORWARDED_FOR' ) ) {
			$ip_address = getenv( 'HTTP_X_FORWARDED_FOR' );
		} else if ( getenv( 'HTTP_X_FORWARDED' ) ) {
			$ip_address = getenv( 'HTTP_X_FORWARDED' );
		} else if ( getenv( 'HTTP_FORWARDED_FOR' ) ) {
			$ip_address = getenv( 'HTTP_FORWARDED_FOR' );
		} else if ( getenv( 'HTTP_FORWARDED' ) ) {
			$ip_address = getenv( 'HTTP_FORWARDED' );
		} else if ( getenv( 'REMOTE_ADDR' ) ) {
			$ip_address = getenv( 'REMOTE_ADDR' );
		} else {
			$ip_address = 'UNKNOWN';
		}

		return $ip_address;
	}

	public function action_woocommerce_update_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( !empty( $order ) && $order->get_status() != 'failed' ) {
			$this->add_woocommerce_transaction_leads( $order_id );
			if ( is_array( @$order_items = $order->get_items() ) ) {
				foreach ( $order_items as $item ) {
					$product_id = $item[ 'product_id' ];
					$this->add_woocommerce_specific_transaction_leads( $product_id, $order_id );
				}
			}
		}
	}

	public function action_woocommerce_add_to_cart( $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data ) {
		global $wpdb;

		$table_woocommerce_data = $wpdb->prefix . TABLE_BOOSTS_WOOCOMMERCE_DATA;
		$table_boosts = $wpdb->prefix . TABLE_BOOSTS;

		$sql = "SELECT $table_boosts.`id`, $table_boosts.`type` FROM $table_boosts
				LEFT JOIN $table_woocommerce_data ON ($table_woocommerce_data.`boost_id` = $table_boosts.`id`)
				WHERE $table_boosts.`active` = '1' AND $table_boosts.`draft` <> '1' AND $table_boosts.`type` LIKE 'woocommerce' AND $table_woocommerce_data.`subtype` LIKE 'add_to_cart'";

		$boosts = $wpdb->get_results( $sql, ARRAY_A );
		if ( !empty( $boosts ) ) {
			foreach ( $boosts as $boost ) {
				$this->action_model->create_action_entry( $boost[ 'id' ], $boost[ 'type' ], '-', null, $product_id );
			}
		}
	}

	public function add_woocommerce_transaction_leads( $order_id ) {
		global $wpdb;

		$table_woocommerce_data = $wpdb->prefix . TABLE_BOOSTS_WOOCOMMERCE_DATA;
		$table_boosts = $wpdb->prefix . TABLE_BOOSTS;

		$sql = "SELECT $table_boosts.`id`, $table_boosts.`type` FROM $table_boosts
				LEFT JOIN $table_woocommerce_data ON ($table_woocommerce_data.`boost_id` = $table_boosts.`id`)
				WHERE $table_boosts.`active` = '1' AND $table_boosts.`draft` <> '1' AND $table_boosts.`type` LIKE 'woocommerce' AND $table_woocommerce_data.`subtype` LIKE 'transaction'";

		$boosts = $wpdb->get_results( $sql, ARRAY_A );
		if ( !empty( $boosts ) ) {
			foreach ( $boosts as $boost ) {
				if ( !$this->action_model->check_action_exists( array(
					'boost_id'   => array(
						'compare' => '=',
						'value'   => $boost[ 'id' ]
					),
					'order_id'   => array(
						'compare' => '=',
						'value'   => $order_id
					),
					'product_id' => array(
						'compare' => '',
						'value'   => 'IS NULL'
					)
				) ) ) {

					$order = wc_get_order( $order_id );
					$order_items = $order->get_items();
					if ( !empty( $order_items ) ) {
						foreach ( $order_items as $item ) {
							$product_id = $item[ 'product_id' ];
							$order_date_created = $order->get_date_created();
							$order_date_created = $order_date_created instanceof DateTime ? $order_date_created->getTimestamp() : time();
							$user_location = $this->action_model->get_user_location_from_wc_order( $order );
							$user_name = $this->action_model->get_user_name( $boost[ 'type' ], '', $order, false );
							$this->action_model->create_action_entry( $boost[ 'id' ], $boost[ 'type' ], $user_name, $order_id, $product_id, $order_date_created, $user_location );
						}
					} else {
						$this->action_model->create_action_entry( $boost[ 'id' ], $boost[ 'type' ], '', $order_id, null );
					}
				}
			}
		}
	}

	public function add_woocommerce_specific_transaction_leads( $product_id, $order_id ) {
		global $wpdb;

		$table_woocommerce_data = $wpdb->prefix . TABLE_BOOSTS_WOOCOMMERCE_DATA;
		$table_woocommerce_products = $wpdb->prefix . TABLE_BOOSTS_WOOCOMMERCE_PRODUCTS;
		$table_woocommerce_categories = $wpdb->prefix . TABLE_BOOSTS_WOOCOMMERCE_CATEGORIES;
		$table_boosts = $wpdb->prefix . TABLE_BOOSTS;

		if ( function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $product_id );
			if ( !empty( $product ) ) {
				$product_cats = $product->get_category_ids();

				$sql = "SELECT DISTINCT ($table_boosts.`id`), $table_boosts.`type` FROM $table_boosts
									LEFT JOIN $table_woocommerce_data ON ($table_woocommerce_data.`boost_id` = $table_boosts.`id`)
									LEFT JOIN $table_woocommerce_products ON ($table_woocommerce_products.`boost_id` = $table_boosts.`id`)
									LEFT JOIN $table_woocommerce_categories ON ($table_woocommerce_categories.`boost_id` = $table_boosts.`id`)
									WHERE $table_boosts.`active` = '1' AND $table_boosts.`draft` <> '1' AND $table_boosts.`type` LIKE 'woocommerce' AND $table_woocommerce_data.`subtype` LIKE 'specific_transaction'
										AND ($table_woocommerce_products.`product_id` = '$product_id' OR $table_woocommerce_categories.`category_id` IN ('" . implode( "','", $product_cats ) . "'))";

				$boosts = $wpdb->get_results( $sql, ARRAY_A );
				if ( !empty( $boosts ) ) {
					foreach ( $boosts as $boost ) {
						if ( !$this->action_model->check_action_exists( array(
							'boost_id'   => array(
								'compare' => '=',
								'value'   => $boost[ 'id' ]
							),
							'order_id'   => array(
								'compare' => '=',
								'value'   => $order_id
							),
							'product_id' => array(
								'compare' => '=',
								'value'   => $product_id
							)
						) ) ) {
							$this->action_model->create_action_entry( $boost[ 'id' ], $boost[ 'type' ], '', $order_id, $product_id );
						}
					}
				}
			}
		}
	}

	public function action_edd_complete_purchase( $payment_id ) {
		global $wpdb;

		$table_easydigitaldownloads_data = $wpdb->prefix . TABLE_BOOSTS_EASYDIGITALDOWNLOADS_DATA;
		$table_boosts = $wpdb->prefix . TABLE_BOOSTS;

		$sql = "SELECT $table_boosts.`id`,$table_boosts.`type`  FROM $table_boosts
				LEFT JOIN $table_easydigitaldownloads_data ON ($table_easydigitaldownloads_data.`boost_id` = $table_boosts.`id`)
				WHERE $table_boosts.`active` = '1' AND $table_boosts.`draft` <> '1' AND $table_boosts.`type` LIKE 'easydigitaldownloads' AND $table_easydigitaldownloads_data.`subtype` LIKE 'transaction'";

		$payment_meta = edd_get_payment_meta( $payment_id );
		$boosts = $wpdb->get_results( $sql, ARRAY_A );
		if ( !empty( $boosts ) ) {
			foreach ( $boosts as $boost ) {
				if ( !empty( $payment_meta[ 'downloads' ] ) ) {
					foreach ( $payment_meta[ 'downloads' ] as $download ) {
						$this->action_model->create_action_entry( $boost[ 'id' ], $boost[ 'type' ], '', $payment_id, $download[ 'id' ] );
					}
				} else {
					$this->action_model->create_action_entry( $boost[ 'id' ], $boost[ 'type' ], '', $payment_id, null );
				}
			}
		}
	}

	public function action_edd_complete_download_purchase( $download_id, $payment_id, $download_type ) {
		global $wpdb;

		$table_easydigitaldownloads_data = $wpdb->prefix . TABLE_BOOSTS_EASYDIGITALDOWNLOADS_DATA;
		$table_easydigitaldownloads_products = $wpdb->prefix . TABLE_BOOSTS_EASYDIGITALDOWNLOADS_PRODUCTS;
		$table_easydigitaldownloads_categories = $wpdb->prefix . TABLE_BOOSTS_EASYDIGITALDOWNLOADS_CATEGORIES;
		$table_boosts = $wpdb->prefix . TABLE_BOOSTS;

		if ( !is_array( $download_cats = wp_get_post_terms( $download_id, 'download_category', array( 'fields' => 'ids' ) ) ) ) {
			$download_cats = array();
		};

		$sql = "SELECT DISTINCT ($table_boosts.`id`), $table_boosts.`type` FROM $table_boosts
									LEFT JOIN $table_easydigitaldownloads_data ON ($table_easydigitaldownloads_data.`boost_id` = $table_boosts.`id`)
									LEFT JOIN $table_easydigitaldownloads_products ON ($table_easydigitaldownloads_products.`boost_id` = $table_boosts.`id`)
									LEFT JOIN $table_easydigitaldownloads_categories ON ($table_easydigitaldownloads_categories.`boost_id` = $table_boosts.`id`)
									WHERE $table_boosts.`active` = '1' AND $table_boosts.`draft` <> '1' AND $table_boosts.`type` LIKE 'easydigitaldownloads' AND $table_easydigitaldownloads_data.`subtype` LIKE 'specific_transaction'
										AND ($table_easydigitaldownloads_products.`product_id` = '$download_id' OR $table_easydigitaldownloads_categories.`category_id` IN ('" . implode( "','", $download_cats ) . "'))";

		$boosts = $wpdb->get_results( $sql, ARRAY_A );
		if ( !empty( $boosts ) ) {
			foreach ( $boosts as $boost ) {
				$this->action_model->create_action_entry( $boost[ 'id' ], $boost[ 'type' ], '', $payment_id, $download_id );
			}
		}
	}

	public function action_edd_post_add_to_cart( $download_id, $options, $items ) {
		global $wpdb;

		$table_easydigitaldownloads_data = $wpdb->prefix . TABLE_BOOSTS_EASYDIGITALDOWNLOADS_DATA;
		$table_boosts = $wpdb->prefix . TABLE_BOOSTS;

		$sql = "SELECT $table_boosts.`id`, $table_boosts.`type` FROM $table_boosts
				LEFT JOIN $table_easydigitaldownloads_data ON ($table_easydigitaldownloads_data.`boost_id` = $table_boosts.`id`)
				WHERE $table_boosts.`active` = '1' AND $table_boosts.`draft` <> '1' AND $table_boosts.`type` LIKE 'easydigitaldownloads' AND $table_easydigitaldownloads_data.`subtype` LIKE 'add_to_cart'";

		$boosts = $wpdb->get_results( $sql, ARRAY_A );
		if ( !empty( $boosts ) ) {
			foreach ( $boosts as $boost ) {
				$this->action_model->create_action_entry( $boost[ 'id' ], $boost[ 'type' ], '-', null, $download_id );
			}
		}
	}

	public function check_elementor_editor() {

		if ( ( is_plugin_active( 'elementor/elementor.php' ) || is_plugin_active( 'elementor-pro/elementor-pro.php' ) ) && ( \Elementor\Plugin::$instance->preview->is_preview_mode() || \Elementor\Plugin::$instance->editor->is_edit_mode() ) ) {
			return true;
		} else {
			return false;
		}
	}
}