<?php
/**
 * Ninja Form File.
 *
 * @link       https://www.pixelyoursite.com/boost-plugin
 * @since      2.0.0
 *
 * @package    Boost
 * @subpackage Boost/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Boost
 * @subpackage Boost/admin
 * @author     https://www.pixelyoursite.com/boost-plugin
 */

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class FormNinjaForm {

	private static $_instance;

	private static $exclude_field_types = array(
		'starrating',
		'recaptcha',
		'spam',
		'hidden',
		'confirm',
		'html',
		'total',
		'liststate',
		'submit',
		'listselect',
		'listradio',
		'listmultiselect',
		'listcheckbox',
		'date',
		'checkbox',
		'listcountry',
		'number',
		'hr',
		'total',
		'product',
		'shipping',
		'quantity'
	);

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}


	public function __construct() {

	}

	public function isActivePlugin() {
		if ( !function_exists( 'is_plugin_active' ) ) {
			include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		}

		return is_plugin_active( 'ninja-forms/ninja-forms.php' );
	}

	public function getForms() {

		$forms = array();
		if ( $this->isActivePlugin() ) {
			global $wpdb, $table_prefix;
			$forms = $wpdb->get_results( $wpdb->prepare( 'SELECT id, title FROM ' . $table_prefix . 'nf3_forms ORDER BY %s DESC', "created_at" ) );
			$forms = wp_list_pluck( $forms, 'title', 'id' );
		}

		return $forms;
	}

	public function getFields( $form_id, $form_title = '' ) {

		$forms_data = array();
		if ( $this->isActivePlugin() ) {

			$form_html = do_shortcode( "[ninja_form id='{$form_id}']" );
			$dom = new DomDocument();
			@$dom->loadHTML( $form_html );

			$xpath = new DomXPath( $dom );

			$forms = $xpath->query( './/div[@role="form"]' );

			foreach ( $forms as $form ) {

				$form_fields_data = array();
				$form_fields = Ninja_Forms()->form( $form_id )->get_fields();
				foreach ( $form_fields as $form_field ) {
					$field_type = $form_field->get_setting( 'type' );
					if ( in_array( $field_type, self::$exclude_field_types ) ) continue;
					$field_id = $form_field->get_id();

					$form_fields_data[] = array(
						'id'    => 'nf-field-' . $field_id,
						'name'  => 'nf-field-' . $field_id,
						'value' => 'nf-field-' . $field_id,
						'type'  => '',
						'class' => '',
					);
				}

				$form_fields_data[] = array(
					'id'       => 'boost_empty_field',
					'name'     => esc_html__( 'Leave empty', 'boost' ),
					'value'    => '',
					'type'     => '',
					'class'    => 'empty_select',
					'selector' => ''
				);

				$forms_data = array(
					'id'       => $form->getAttribute( 'id' ),
					'title'    => $form_title,
					'class'    => $form->getAttribute( 'class' ),
					'action'   => $form->getAttribute( 'action' ),
					'method'   => $form->getAttribute( 'method' ),
					'selector' => $this->getFullCSSSelector( $form, $xpath->query( './/body' )->item( 1 ) ),
					'fields'   => $form_fields_data
				);
			}
		}

		return $forms_data;
	}

	private function getFullCSSSelector( $node, $pNode ) {
		$nodeID = $this->getNodeID( $node );
		if ( $nodeID != '' ) {
			return $node->nodeName . '#' . $nodeID;
		} elseif ( $node->nodeName == 'body' || $node == $pNode ) {
			return $node->nodeName;
		} else {
			return $this->getFullCSSSelector( $node->parentNode, $pNode ) . '>' . $node->nodeName;
		}
	}

	private function getNodeID( $node ) {
		$nodeID = '';
		$nodeAttrs = $node->attributes;
		foreach ( $nodeAttrs as $nodeAttr ) {
			if ( $nodeAttr->nodeName == 'id' ) {
				$nodeID = $nodeAttr->nodeValue;
			}
		}

		return $nodeID;
	}

}

/**
 * @return FormNinjaForm::instance
 */
function FormNinjaForm() {
	return FormNinjaForm::instance();
}
