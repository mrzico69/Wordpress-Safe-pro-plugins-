<?php
/**
 * WPForms Form File.
 *
 * @link       https://www.pixelyoursite.com/boost-plugin
 * @since      2.0.0
 *
 * @package    Boost
 * @subpackage Boost/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Boost
 * @subpackage Boost/admin
 * @author     https://www.pixelyoursite.com/boost-plugin
 */

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class FormWPForms {

	private static $_instance;

	private static $accepted_fields = array(
		'text',
		'email',
		'tel',
	);

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function __construct() {

	}

	public function isActivePlugin() {
		if ( !function_exists( 'is_plugin_active' ) ) {
			include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		}

		return is_plugin_active( 'wpforms-lite/wpforms.php' ) || is_plugin_active( 'wpforms/wpforms.php' );
	}

	public function getForms() {

		$forms = array();
		if ( $this->isActivePlugin() ) {
			global $wpdb;
			$forms = $wpdb->get_results( $wpdb->prepare( 'SELECT ID, post_title FROM ' . $wpdb->posts . ' WHERE post_type = %s AND post_status = %s', "wpforms", "publish" ) );
			$forms = wp_list_pluck( $forms, 'post_title', 'ID' );
		}

		return $forms;
	}

	public function getFields( $form_id, $form_title = '' ) {

		$forms_data = array();
		if ( $this->isActivePlugin() ) {

			$form_html = do_shortcode( "[wpforms id='{$form_id}']" );

			$dom = new DomDocument();
			@$dom->loadHTML( $form_html );

			$xpath = new DomXPath( $dom );

			$form_query = "@type='" . implode( "' or @type='", self::$accepted_fields ) . "'";
			$forms = $xpath->query( './/form' );

			foreach ( $forms as $form ) {
				$form_fields_data = array();
				$form_fields = $xpath->query( ".//input[{$form_query}]", $form );

				foreach ( $form_fields as $form_field ) {

					$form_fields_data[] = array(
						'id'       => $form_field->getAttribute( 'id' ),
						'name'     => $form_field->getAttribute( 'name' ),
						'value'    => $form_field->getAttribute( 'name' ),
						'type'     => $form_field->getAttribute( 'type' ),
						'class'    => $form_field->getAttribute( 'class' ),
						'selector' => $this->getFullCSSSelector( $form_field, $form )
					);
				}

				$form_fields_data[] = array(
					'id'       => 'boost_empty_field',
					'name'     => esc_html__( 'Leave empty', 'boost' ),
					'value'    => '',
					'type'     => '',
					'class'    => 'empty_select',
					'selector' => ''
				);

				$forms_data = array(
					'id'       => $form->getAttribute( 'id' ),
					'title'    => $form_title,
					'class'    => $form->getAttribute( 'class' ),
					'action'   => $form->getAttribute( 'action' ),
					'method'   => $form->getAttribute( 'method' ),
					'selector' => $this->getFullCSSSelector( $form, $xpath->query( './/body' )->item( 1 ) ),
					'fields'   => $form_fields_data
				);
			}
		}

		return $forms_data;
	}

	private function getFullCSSSelector( $node, $pNode ) {
		$nodeID = $this->getNodeID( $node );
		if ( $nodeID != '' ) {
			return $node->nodeName . '#' . $nodeID;
		} elseif ( $node->nodeName == 'body' || $node == $pNode ) {
			return $node->nodeName;
		} else {
			return $this->getFullCSSSelector( $node->parentNode, $pNode ) . '>' . $node->nodeName;
		}
	}

	private function getNodeID( $node ) {
		$nodeID = '';
		$nodeAttrs = $node->attributes;
		foreach ( $nodeAttrs as $nodeAttr ) {
			if ( $nodeAttr->nodeName == 'id' ) {
				$nodeID = $nodeAttr->nodeValue;
			}
		}

		return $nodeID;
	}

}

/**
 * @return FormWPForms::instance
 */
function FormWPForms() {
	return FormWPForms::instance();
}
