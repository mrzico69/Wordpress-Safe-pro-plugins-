<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://www.pixelyoursite.com/boost-plugin
 * @since      1.0.0
 *
 * @package    Boost
 * @subpackage Boost/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Boost
 * @subpackage Boost/includes
 * @author     https://www.pixelyoursite.com/boost-plugin
 */
class BoostDeactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {
		BoostDeactivator::cronstarter_deactivate();
	}

	// unschedule event upon plugin deactivation
	public static function cronstarter_deactivate() {
		$timestamp = wp_next_scheduled( 'boost_fake_boosts_job' );
		// unschedule previous event if any
		wp_unschedule_event( $timestamp, 'boost_fake_boosts_job' );
	}

}
