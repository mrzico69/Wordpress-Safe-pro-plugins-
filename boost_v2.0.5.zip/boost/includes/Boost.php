<?php
/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://www.pixelyoursite.com/boost-plugin
 * @since      1.0.0
 *
 * @package    Boost
 * @subpackage Boost/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Boost
 * @subpackage Boost/includes
 * @author     https://www.pixelyoursite.com/boost-plugin
 */
class Boost {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      BoostLoader $loader Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string $plugin_name The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string $version The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {

		$this->plugin_name = 'boost';
		$this->version = BOOST_PLUGIN_VERSION;

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
		$this->check_upgrades();
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - BoostLoader. Orchestrates the hooks of the plugin.
	 * - Boost_i18n. Defines internationalization functionality.
	 * - BoostAdmin. Defines all hooks for the admin area.
	 * - BoostPublic. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once BOOST_PLUGIN_PATH . 'includes/BoostLoader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once BOOST_PLUGIN_PATH . 'includes/Boost_i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once BOOST_PLUGIN_PATH . 'admin/BoostAdmin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once BOOST_PLUGIN_PATH . 'public/BoostPublic.php';

		require_once BOOST_PLUGIN_PATH . 'includes/BoostActionModel.php';

		require_once BOOST_PLUGIN_PATH . 'includes/BoostBoostModel.php';

		require_once BOOST_PLUGIN_PATH . 'includes/BoostSettingsModel.php';

		require_once BOOST_PLUGIN_PATH . 'includes/BoostNotificationModel.php';

		require_once BOOST_PLUGIN_PATH . 'includes/BoostBannedWordModel.php';

		require_once BOOST_PLUGIN_PATH . 'includes/BoostLicense.php';

		$this->loader = new BoostLoader();
	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Boost_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Boost_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_settings = new BoostSettingsModel( $this->get_plugin_name(), $this->get_version() );
		$settings = $plugin_settings->get_settings();

		if ( $settings[ 'check_integrations_table' ] != BOOST_PLUGIN_VERSION ) {
			$this->installation_missing_tables( 'integrated_forms' );
			$plugin_settings->update_settings( array( 'check_integrations_table' => BOOST_PLUGIN_VERSION ) );
		}

		if ( $settings[ 'check_banned_words' ] != BOOST_PLUGIN_VERSION ) {
			$this->installation_missing_tables( 'banned_words' );
			$plugin_settings->update_settings( array( 'check_banned_words' => BOOST_PLUGIN_VERSION ) );
		}

		if ( $settings[ 'check_actions_table' ] != BOOST_PLUGIN_VERSION ) {
			$this->installation_missing_tables( 'actions' );
			$plugin_settings->update_settings( array( 'check_actions_table' => BOOST_PLUGIN_VERSION ) );
		}

		$plugin_admin = new BoostAdmin( $this->get_plugin_name(), $this->get_version() );

		$action_model = new BoostActionModel( $this->get_plugin_name(), $this->get_version() );

		$license = new BoostLicense();

		$this->loader->add_action( 'admin_menu', $plugin_admin, 'boost_main_menu' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

		$this->loader->add_action( 'init', $license, 'check_license' );
		$this->loader->add_action( 'admin_init', $license, 'update_plugin' );

		if ( $license->license_exist() ) {
			$this->loader->add_action( 'wp_ajax_boost_search_items_ajax', $plugin_admin, 'boost_search_items_ajax_handler' );

			$this->loader->add_action( 'wp_ajax_boost_edit_item_ajax', $plugin_admin, 'boost_edit_item_ajax_handler' );

			$this->loader->add_action( 'wp_ajax_boost_search_forms_ajax', $plugin_admin, 'boost_search_forms_ajax_handler' );
			$this->loader->add_action( 'init', $plugin_admin, 'boost_cronstarter_activation' );
			$this->loader->add_action( 'boost_fake_boosts_job', $action_model, 'cron_job' );
		}
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {
		$license = new BoostLicense();

		if ( $license->license_exist() ) {
			$plugin_public = new BoostPublic( $this->get_plugin_name(), $this->get_version() );

			$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
			$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

			$this->loader->add_action( 'wp_ajax_nopriv_boost_submit_form_ajax', $plugin_public, 'boost_submit_form_ajax_handler' );
			$this->loader->add_action( 'wp_ajax_boost_submit_form_ajax', $plugin_public, 'boost_submit_form_ajax_handler' );

			$this->loader->add_action( 'wp_ajax_nopriv_boost_notifications_part_load_ajax', $plugin_public, 'boost_notifications_part_load_ajax_handler' );
			$this->loader->add_action( 'wp_ajax_boost_notifications_part_load_ajax', $plugin_public, 'boost_notifications_part_load_ajax_handler' );

			$this->loader->add_action( 'woocommerce_checkout_order_processed', $plugin_public, 'action_woocommerce_update_order' );
			$this->loader->add_action( 'woocommerce_add_to_cart', $plugin_public, 'action_woocommerce_add_to_cart', 10, 6 );

			$this->loader->add_action( 'edd_complete_purchase', $plugin_public, 'action_edd_complete_purchase', 10, 1 );
			$this->loader->add_action( 'edd_complete_download_purchase', $plugin_public, 'action_edd_complete_download_purchase', 10, 3 );
			$this->loader->add_action( 'edd_post_add_to_cart', $plugin_public, 'action_edd_post_add_to_cart', 10, 3 );
		}
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @return    string    The name of the plugin.
	 * @since     1.0.0
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @return    string    The version number of the plugin.
	 * @since     1.0.0
	 */
	public function get_version() {
		return $this->version;
	}

	private function check_upgrades() {

		$version = get_option( 'boost_version', false );

		// data scheme is actual
		if ( ( $version && version_compare( $version, $this->version, '>=' ) ) || !$version ) {
			return;
		}

		require_once BOOST_PLUGIN_PATH . 'includes/upgrade.php';

		if ( version_compare( $version, '1.0.3', '<' ) ) {
			boost_upgrade_to_1_0_3();
		}

		if ( version_compare( $version, '2.0.2.2', '<' ) ) {
			boost_upgrade_to_2_0_2_2();
		}

		update_option( 'boost_version', $this->version );
	}

	private function installation_missing_tables( $table ) {

		global $wpdb;
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

		switch ( $table ) {
			case 'integrated_forms':
				$table_integrated_forms_data = $wpdb->prefix . TABLE_BOOSTS_INTEGRATED_FORMS_DATA;
				$sql = "CREATE TABLE $table_integrated_forms_data (
 					`id` INT NOT NULL AUTO_INCREMENT , 
 				  	`boost_id` INT NOT NULL , 
 				  	`integrated_form` VARCHAR(200) NOT NULL , 
 				  	`form_id` INT NOT NULL , 
 				  	`form_selector` VARCHAR(200) NOT NULL , 
 				  	`form_username_field` VARCHAR(50) NOT NULL , 
 				  	`form_surname_field` VARCHAR(50) NOT NULL , 
 				  	PRIMARY KEY (`id`));";

				dbDelta( $sql );
				break;
			case 'banned_words':
				$table_banned_words = $wpdb->prefix . TABLE_BANNED_WORDS;
				$sql = "CREATE TABLE $table_banned_words (
				  `id` INT NOT NULL AUTO_INCREMENT,
				  `word` VARCHAR(50) CHARACTER SET utf8 NOT NULL,
				  PRIMARY KEY (`id`));";

				dbDelta( $sql );

				require_once BOOST_PLUGIN_PATH . 'includes/BoostActivator.php';
				BoostActivator::init_banned_words();

				break;
			case 'actions':
				$table_actions = $wpdb->prefix . TABLE_ACTIONS;
				$sql = "CREATE TABLE $table_actions (
 					`id` INT NOT NULL AUTO_INCREMENT , 
 					`captured_data` VARCHAR(100) CHARACTER SET utf8 NOT NULL , 
 					`boost_id` INT NOT NULL , 
 					`user_name` VARCHAR(100) CHARACTER SET utf8 NOT NULL , 
 					`order_id` INT , 
 					`product_id` BIGINT , 
 					`time` INT NOT NULL , 
 					`town` VARCHAR(100) CHARACTER SET utf8 NOT NULL , 
 					`state` VARCHAR(100) CHARACTER SET utf8 NOT NULL , 
 					`country` VARCHAR(100) CHARACTER SET utf8 NOT NULL , 
 					`fake` TINYINT(1) NOT NULL , 
 					 PRIMARY KEY (`id`),
 					 INDEX `BOOSTID` (`boost_id`));";

				dbDelta( $sql );

				break;
			default:
				break;
		}
	}
}
