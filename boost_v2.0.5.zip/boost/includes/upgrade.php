<?php

function boost_upgrade_to_1_0_3() {

	add_action('init', function () {
		$boost_model = new BoostBoostModel( BOOST_PLUGIN_NAME, BOOST_PLUGIN_VERSION );

		$all_boosts = $boost_model->get_boosts( array() );

		foreach ( $all_boosts as $boost ) {
			$boost_data = stripslashes_deep( (array) $boost );
			$boost_model->update_boost( $boost_data[ 'id' ], $boost_data );
		}
	});
}

function boost_upgrade_to_2_0_2_2() {

	global $wpdb;
	$table_woocommerce_products = $wpdb->prefix . TABLE_BOOSTS_WOOCOMMERCE_PRODUCTS;
	$table_woocommerce_categories = $wpdb->prefix . TABLE_BOOSTS_WOOCOMMERCE_CATEGORIES;
	$table_easydigitaldownloads_products = $wpdb->prefix . TABLE_BOOSTS_EASYDIGITALDOWNLOADS_PRODUCTS;
	$table_easydigitaldownloads_categories = $wpdb->prefix . TABLE_BOOSTS_EASYDIGITALDOWNLOADS_CATEGORIES;
	$table_actions = $wpdb->prefix . TABLE_ACTIONS;
	$table_boosts_specific_pages = $wpdb->prefix . TABLE_BOOSTS_SPECIFIC_PAGES;
	$table_boosts_exclude_specific_pages = $wpdb->prefix . TABLE_BOOSTS_EXCLUDE_SPECIFIC_PAGES;
	$table_boosts_products = $wpdb->prefix . TABLE_BOOSTS_PRODUCTS;
	$table_boosts_product_categories = $wpdb->prefix . TABLE_BOOSTS_PRODUCT_CATEGORIES;

	$sql = "ALTER TABLE $table_woocommerce_products MODIFY COLUMN product_id BIGINT";
	$wpdb->query( $sql );

	$sql = "ALTER TABLE $table_woocommerce_categories MODIFY COLUMN category_id BIGINT";
	$wpdb->query( $sql );

	$sql = "ALTER TABLE $table_easydigitaldownloads_products MODIFY COLUMN product_id BIGINT";
	$wpdb->query( $sql );

	$sql = "ALTER TABLE $table_easydigitaldownloads_categories MODIFY COLUMN category_id BIGINT";
	$wpdb->query( $sql );

	$sql = "ALTER TABLE $table_actions 
        MODIFY COLUMN order_id BIGINT,
        MODIFY COLUMN product_id BIGINT";
	$wpdb->query( $sql );

	$sql = "ALTER TABLE $table_boosts_specific_pages MODIFY COLUMN post_id BIGINT";
	$wpdb->query( $sql );

	$sql = "ALTER TABLE $table_boosts_exclude_specific_pages MODIFY COLUMN post_id BIGINT";
	$wpdb->query( $sql );

	$sql = "ALTER TABLE $table_boosts_products MODIFY COLUMN product_id BIGINT";
	$wpdb->query( $sql );

	$sql = "ALTER TABLE $table_boosts_product_categories MODIFY COLUMN category_id BIGINT";
	$wpdb->query( $sql );
}